<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Event\Event;

class BooksTable extends Table
{

    public function initialize(array $config)
    {
        
    }

}